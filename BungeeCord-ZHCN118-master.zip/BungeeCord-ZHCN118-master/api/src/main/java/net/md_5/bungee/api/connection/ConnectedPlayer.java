package net.md_5.bungee.api.connection;

/**
 * Represents a player physically connected to the world hosted on this server.
 */
public interface ConnectedPlayer extends ProxiedPlayer
{
}
