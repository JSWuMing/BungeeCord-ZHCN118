package net.md_5.bungee.protocol;

import lombok.Data;

@Data
public class Location
{

    private final String dimension;
    private final long pos;
}
