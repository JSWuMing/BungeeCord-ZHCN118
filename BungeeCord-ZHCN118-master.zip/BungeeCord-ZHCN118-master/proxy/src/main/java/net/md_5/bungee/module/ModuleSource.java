package net.md_5.bungee.module;

interface ModuleSource
{

    void retrieve(ModuleSpec module, ModuleVersion version);
}
